document.querySelectorAll('.avatar-opcao').forEach(botao => {
    botao.addEventListener('click', () => {
        document.querySelectorAll('.avatar-opcao').forEach(item => item.classList.remove('selected'));
        botao.classList.add('selected');
        const input = document.getElementById('poney-escolhido');
        if (input) input.value = botao.dataset.poney;
    });
});

function filtrarJogos() {
    const pesquisa = document.getElementById('pesquisa');
    if (!pesquisa) return;

    const valor = pesquisa.value.toLowerCase();
    document.querySelectorAll('.jogo-card').forEach(card => {
        const nome = card.getAttribute('data-nome') || '';
        card.style.display = nome.includes(valor) ? 'block' : 'none';
    });
}

function filtrarCategoria(cat) {
    document.querySelectorAll('.jogo-card').forEach(card => {
        const categoria = card.getAttribute('data-cat');
        card.style.display = (cat === 'todos' || categoria === cat) ? 'block' : 'none';
    });
}
