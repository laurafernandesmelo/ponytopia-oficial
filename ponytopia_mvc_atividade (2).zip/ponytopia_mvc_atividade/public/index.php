<?php

declare(strict_types=1);

session_start();

spl_autoload_register(function (string $class): void {
    $baseDir = dirname(__DIR__) . DIRECTORY_SEPARATOR;
    $paths = [
        $baseDir . 'app/' . $class . '.php',
        $baseDir . 'app/controllers/' . $class . '.php',
        $baseDir . 'app/services/' . $class . '.php',
        $baseDir . 'app/models/' . $class . '.php',
        $baseDir . 'app/database/' . $class . '.php',
    ];

    foreach ($paths as $path) {
        if (is_file($path)) {
            require_once $path;
            return;
        }
    }
});

$router = new Router();
require dirname(__DIR__) . '/routes/web.php';
$router->dispatch($_SERVER['REQUEST_URI'], $_SERVER['REQUEST_METHOD']);
