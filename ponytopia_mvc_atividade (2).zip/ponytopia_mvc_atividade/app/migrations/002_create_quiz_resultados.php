<?php

declare(strict_types=1);

return function (PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS quiz_resultados (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        usuario_id INTEGER NULL,
        nome_usuario TEXT NOT NULL,
        resultado TEXT NOT NULL,
        created_at TEXT NOT NULL
    )");
};
