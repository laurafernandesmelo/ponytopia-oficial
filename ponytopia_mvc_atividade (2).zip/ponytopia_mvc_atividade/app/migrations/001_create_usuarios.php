<?php

declare(strict_types=1);

return function (PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS usuarios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL UNIQUE,
        nascimento TEXT,
        genero TEXT,
        senha_hash TEXT NOT NULL,
        poney TEXT NOT NULL,
        created_at TEXT NOT NULL
    )");
};
