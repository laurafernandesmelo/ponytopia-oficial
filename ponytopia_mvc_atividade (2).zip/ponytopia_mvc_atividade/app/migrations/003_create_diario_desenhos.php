<?php

declare(strict_types=1);

return function (PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS diario_desenhos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        usuario_id INTEGER NULL,
        titulo TEXT,
        observacao TEXT,
        created_at TEXT NOT NULL
    )");
};
