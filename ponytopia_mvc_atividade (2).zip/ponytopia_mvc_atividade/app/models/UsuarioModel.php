<?php

declare(strict_types=1);

class UsuarioModel
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getConnection();
    }

    public function criar(array $dados): int
    {
        $sql = "INSERT INTO usuarios (nome, nascimento, genero, senha_hash, poney, created_at)
                VALUES (:nome, :nascimento, :genero, :senha_hash, :poney, datetime('now'))";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            ':nome' => $dados['nome'],
            ':nascimento' => $dados['nascimento'],
            ':genero' => $dados['genero'],
            ':senha_hash' => $dados['senha_hash'],
            ':poney' => $dados['poney'],
        ]);

        return (int)$this->db->lastInsertId();
    }

    public function buscarPorNome(string $nome): ?array
    {
        $stmt = $this->db->prepare('SELECT * FROM usuarios WHERE nome = :nome LIMIT 1');
        $stmt->execute([':nome' => $nome]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

        return $usuario ?: null;
    }

    public function listarTodos(): array
    {
        $stmt = $this->db->query('SELECT id, nome, nascimento, genero, poney, created_at FROM usuarios ORDER BY id DESC');
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
