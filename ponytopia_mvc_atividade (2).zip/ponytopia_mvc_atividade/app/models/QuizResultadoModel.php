<?php

declare(strict_types=1);

class QuizResultadoModel
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getConnection();
    }

    public function criar(array $dados): void
    {
        $sql = "INSERT INTO quiz_resultados (usuario_id, nome_usuario, resultado, created_at)
                VALUES (:usuario_id, :nome_usuario, :resultado, datetime('now'))";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            ':usuario_id' => $dados['usuario_id'] ?: null,
            ':nome_usuario' => $dados['nome_usuario'],
            ':resultado' => $dados['resultado'],
        ]);
    }

    public function listarTodos(): array
    {
        $stmt = $this->db->query('SELECT * FROM quiz_resultados ORDER BY id DESC');
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
