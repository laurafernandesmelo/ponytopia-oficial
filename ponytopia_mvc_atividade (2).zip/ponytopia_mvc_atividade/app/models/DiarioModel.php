<?php

declare(strict_types=1);

class DiarioModel
{
    public function descricao(): string
    {
        return 'Model reservado para futuras gravações dos desenhos do PONYCOLOR.';
    }
}
