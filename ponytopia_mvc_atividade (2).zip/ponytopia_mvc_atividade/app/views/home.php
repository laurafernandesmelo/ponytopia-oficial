<?php $usuario = $_SESSION['usuario'] ?? ['nome' => 'Visitante', 'poney' => 'Twilight']; ?>
<main class="home-page">
    <section class="hero-home">
        <div>
            <h1 class="titulo-home">Ponytopia</h1>
            <p class="saudacao">Olá, <span><?= htmlspecialchars($usuario['nome']) ?></span> 👋</p>
            <p class="descricao-home">Escolha uma atividade mágica para começar.</p>
        </div>
    </section>

    <div class="search-box">
        <input type="text" id="pesquisa" placeholder="O que vamos fazer hoje?..." onkeyup="filtrarJogos()">
    </div>

    <div class="categorias">
        <button class="cat" onclick="filtrarCategoria('todos')">Tudo</button>
        <button class="cat" onclick="filtrarCategoria('rpg')">Aventura RPG</button>
        <button class="cat" onclick="filtrarCategoria('quiz')">Testes</button>
        <button class="cat" onclick="filtrarCategoria('social')">Amizade</button>
    </div>

    <section class="jogos-grid" id="grid-jogos">
        <a class="jogo-card" data-nome="mapa rpg aventura" data-cat="rpg" href="/mapa">
            <img src="https://static.wikia.nocookie.net/mlp/images/a/a4/Map_of_Equestria_2015.jpg" alt="Mapa de Equestria">
            <span>Explorar Mapa</span>
        </a>

        <a class="jogo-card" data-nome="quiz elementos personalidade" data-cat="quiz" href="/quiz">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQLcS6NnetzUhMydMsgoVqH--MRvgEEOdM2pB8zBA2XFxGw68DoST-Honi6jydIv-1jm7eHEaLX_DptXWURHIAJ8tr3z4BCihCgEUMnGMpvoQ&s=10" alt="Quiz">
            <span>Teste de Personalidade</span>
        </a>

        <a class="jogo-card" data-nome="diario sentimentos pintura ponycolor" data-cat="social" href="/diario-amizade">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSfsKVElxJR57blusabDhZZgE8RK7COxWgPqowcREHKQ9etkKq3qQT2MfTBAOz0BaqwiXMGaVUsYR5XOHF3mAKRrQxPjIOuhl1ixwRp9JGF&s=10" alt="Diário de Amizade">
            <span>Diário de Amizade</span>
        </a>

        <a class="jogo-card" data-nome="vestir raridade rarity boutique moda" data-cat="social" href="/rarity">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQrX51t_lIv-XJw9lQHe2lkAWGZm6KBkOwrOIpBtnouBpYVWuQsaNGJvRgkhcnROL70xYvyWXk8IYnGdfxp51X6651Mkn2nq1vQg8R3jAWe&s=10" alt="Boutique da Rarity">
            <span>Boutique da Rarity</span>
        </a>
    </section>
</main>
