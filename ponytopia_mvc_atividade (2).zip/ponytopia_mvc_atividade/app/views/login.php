<div class="auth-page">
    <div class="container auth-card">
        <h1 class="fonte-magica">Bem-vindo!</h1>
        <p>Entre para acessar a Ponytopia.</p>

        <?php if (!empty($erro)): ?>
            <div class="alerta-erro"><?= htmlspecialchars($erro) ?></div>
        <?php endif; ?>

        <form method="post" action="/login/entrar">
            <input name="nome" placeholder="Seu nome" required>
            <input name="senha" type="password" placeholder="Sua senha" required>
            <button type="submit">Entrar no Jogo</button>
        </form>

        <a class="botao-secundario" href="/visitante">Entrar como Visitante</a>
        <a class="link-simples" href="/cadastro">Criar conta</a>
    </div>
</div>
