<div class="auth-page">
    <div class="container auth-card cadastro-card">
        <h1 class="fonte-magica">Criar Conta</h1>
        <p>Preencha os dados e escolha seu pônei favorito.</p>

        <?php if (!empty($erro)): ?>
            <div class="alerta-erro"><?= htmlspecialchars($erro) ?></div>
        <?php endif; ?>

        <form method="post" action="/usuarios/salvar" id="form-cadastro">
            <input name="nome" placeholder="Nome de Usuário" value="<?= htmlspecialchars($dados['nome'] ?? '') ?>" required>
            <input name="nascimento" placeholder="Data de Nascimento (dd/mm/aaaa)" maxlength="10" value="<?= htmlspecialchars($dados['nascimento'] ?? '') ?>">

            <select name="genero">
                <option value="">Selecione o Gênero</option>
                <option value="Feminino">Feminino</option>
                <option value="Masculino">Masculino</option>
                <option value="Outro">Outro</option>
            </select>

            <input name="senha" type="password" placeholder="Sua senha" required>
            <input type="hidden" name="poney" id="poney-escolhido" value="<?= htmlspecialchars($dados['poney'] ?? '') ?>">

            <h2 class="subtitulo">Escolha seu Pônei</h2>

            <div class="poney-list">
                <button type="button" class="avatar-opcao" data-poney="Twilight"><img src="https://media.wired.com/photos/59337ed17965e75f5f3c8503/3:2/w_2560%2Cc_limit/MLP-Twilight.jpg" alt="Twilight"><span>Twilight</span></button>
                <button type="button" class="avatar-opcao" data-poney="Fluttershy"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQcko1WFEG5FIPA6grJXd1cWJAXiSHAQP0LdzVhOdGJqpi-V0b0it6CxiKlAjuldaNIOs3DutSq5MAlWRPmgMXkgBnC9iWvw8Kga-tLL_Bh&s=10" alt="Fluttershy"><span>Fluttershy</span></button>
                <button type="button" class="avatar-opcao" data-poney="Rainbow"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSGk1NmbGDPaUJCLlN4uhOtHeJTsAWeBvh3Eg6_wJ0YIOOnbHjn3vZ4NbVPd8XT1D9i_4l21vlY-Xg4sX_8j5nZ5qZexcBFiDbxyxXq_xZdZQ&s=10" alt="Rainbow"><span>Rainbow</span></button>
                <button type="button" class="avatar-opcao" data-poney="Rarity"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQrX51t_lIv-XJw9lQHe2lkAWGZm6KBkOwrOIpBtnouBpYVWuQsaNGJvRgkhcnROL70xYvyWXk8IYnGdfxp51X6651Mkn2nq1vQg8R3jAWe&s=10" alt="Rarity"><span>Rarity</span></button>
                <button type="button" class="avatar-opcao" data-poney="Applejack"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSfsKVElxJR57blusabDhZZgE8RK7COxWgPqowcREHKQ9etkKq3qQT2MfTBAOz0BaqwiXMGaVUsYR5XOHF3mAKRrQxPjIOuhl1ixwRp9JGF&s=10" alt="Applejack"><span>Applejack</span></button>
                <button type="button" class="avatar-opcao" data-poney="Pinkie"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQLcS6NnetzUhMydMsgoVqH--MRvgEEOdM2pB8zBA2XFxGw68DoST-Honi6jydIv-1jm7eHEaLX_DptXWURHIAJ8tr3z4BCihCgEUMnGMpvoQ&s=10" alt="Pinkie"><span>Pinkie</span></button>
            </div>

            <button type="submit">Concluir Cadastro</button>
        </form>

        <a class="link-simples" href="/login">Já tenho conta</a>
    </div>
</div>
