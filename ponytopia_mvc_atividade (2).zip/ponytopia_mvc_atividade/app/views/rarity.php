<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Boutique da Rarity</title>
    <style>
        body {
            margin: 0;
            min-height: 100vh;
            font-family: 'Segoe UI', sans-serif;
            background: radial-gradient(circle, #251242 0%, #050208 100%);
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .voltar {
            position: fixed;
            top: 15px;
            left: 15px;
            background: #cbb4ff;
            color: #0c0418;
            padding: 10px 16px;
            border-radius: 14px;
            text-decoration: none;
            font-weight: bold;
        }
        .app-viewport {
            width: 95%;
            max-width: 650px;
            background: #0c0418;
            border-radius: 25px;
            box-shadow: 0 0 80px rgba(0,0,0,0.95);
            padding: 25px;
            text-align: center;
            border: 3px solid #cbb4ff;
        }
        h1 { color: #cbb4ff; }
        .pony-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }
        .pony-card, .cloth {
            background: white;
            color: #0c0418;
            border-radius: 16px;
            padding: 12px;
            cursor: pointer;
            font-weight: bold;
        }
        .pony-card img {
            width: 100%;
            height: 115px;
            border-radius: 12px;
            object-fit: cover;
        }
        .pony-display {
            min-height: 160px;
            border: 3px solid #cbb4ff;
            border-radius: 25px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
            font-size: 1.4rem;
            font-weight: bold;
            white-space: pre-line;
            background: rgba(255,255,255,0.05);
        }
        .clothes {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
        }
    </style>
</head>
<body>
    <a class="voltar" href="/home">⬅ Voltar para Home</a>
    <div class="app-viewport">
        <h1>Boutique da Rarity</h1>
        <p>Escolha um pônei e depois escolha uma roupa.</p>

        <div class="pony-grid">
            <div class="pony-card" onclick="selectPony('Rarity')"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQrX51t_lIv-XJw9lQHe2lkAWGZm6KBkOwrOIpBtnouBpYVWuQsaNGJvRgkhcnROL70xYvyWXk8IYnGdfxp51X6651Mkn2nq1vQg8R3jAWe&s=10" alt="Rarity"><span>Rarity</span></div>
            <div class="pony-card" onclick="selectPony('Fluttershy')"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQcko1WFEG5FIPA6grJXd1cWJAXiSHAQP0LdzVhOdGJqpi-V0b0it6CxiKlAjuldaNIOs3DutSq5MAlWRPmgMXkgBnC9iWvw8Kga-tLL_Bh&s=10" alt="Fluttershy"><span>Fluttershy</span></div>
            <div class="pony-card" onclick="selectPony('Twilight Sparkle')"><img src="https://media.wired.com/photos/59337ed17965e75f5f3c8503/3:2/w_2560%2Cc_limit/MLP-Twilight.jpg" alt="Twilight"><span>Twilight</span></div>
            <div class="pony-card" onclick="selectPony('Pinkie Pie')"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQLcS6NnetzUhMydMsgoVqH--MRvgEEOdM2pB8zBA2XFxGw68DoST-Honi6jydIv-1jm7eHEaLX_DptXWURHIAJ8tr3z4BCihCgEUMnGMpvoQ&s=10" alt="Pinkie"><span>Pinkie</span></div>
        </div>

        <div id="ponyDisplay" class="pony-display">Escolha um pônei</div>
        <div id="clothes" class="clothes"></div>
    </div>

    <script>
        let selectedPony = "";
        const allClothes = ["Vestido Gala", "Estilo Roxo", "Look Diamante", "Moda Luxo"];

        function selectPony(name) {
            selectedPony = name;
            document.getElementById("ponyDisplay").innerText = name;
            renderClothes();
        }

        function renderClothes() {
            const container = document.getElementById("clothes");
            container.innerHTML = "";
            allClothes.forEach(item => {
                const div = document.createElement("div");
                div.className = "cloth";
                div.innerText = item;
                div.onclick = () => dress(item);
                container.appendChild(div);
            });
        }

        function dress(item) {
            document.getElementById("ponyDisplay").innerText = selectedPony + "\n👗\n" + item;
        }
    </script>
</body>
</html>
