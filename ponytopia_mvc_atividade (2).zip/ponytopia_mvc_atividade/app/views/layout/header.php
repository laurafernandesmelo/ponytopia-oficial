<?php $usuario = $_SESSION['usuario'] ?? null; ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($titulo ?? 'Ponytopia') ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Quicksand:wght@500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/app.css">
</head>
<body>
<?php if ($usuario): ?>
<header class="topo">
    <a class="menu-logo" href="/home">Ponytopia</a>
    <nav class="top-menu">
        <a href="/home">Home</a>
        <a href="/mapa">Mapa</a>
        <a href="/quiz">Quiz</a>
        <a href="/diario-amizade">Diário</a>
        <a href="/rarity">Rarity</a>
        <a href="/resultados">Resultados</a>
        <a href="/usuarios">Usuários</a>
        <a href="/logout">Sair</a>
    </nav>
</header>
<?php endif; ?>
