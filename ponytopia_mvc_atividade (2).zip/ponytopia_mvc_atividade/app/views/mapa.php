<main class="mapa-page">
    <a class="voltar" href="/home">⬅ Voltar para Home</a>
    <section class="mapa-card">
        <h1 id="mapa-titulo">Mapa de Equestria</h1>
        <div class="mapa-imagem-area">
            <button class="mapa-seta esquerda" onclick="lugarAnterior()">‹</button>
            <img id="mapa-imagem" src="" alt="Lugar de Equestria">
            <button class="mapa-seta direita" onclick="proximoLugar()">›</button>
        </div>
        <div id="mapa-descricao">Explore os lugares mágicos de Equestria</div>
        <div id="mapa-contador">Lugar 1 de 12</div>
    </section>
</main>

<script>
const lugaresEquestria = [
    {nome: "Mapa de Equestria", descricao: "Visão geral do mapa de Equestria.", img: "https://static.wikia.nocookie.net/mlp/images/1/14/MapaEquestriaTraduzido.png/revision/latest/scale-to-width-down/1000?cb=20140606004942&path-prefix=pt"},
    {nome: "Castelo de Canterlot", descricao: "Um dos lugares mais importantes de Equestria.", img: "https://static.wikia.nocookie.net/mlp/images/8/82/Celestia_Harmony_S01E01.png/revision/latest/scale-to-width-down/1000?cb=20140620003157&path-prefix=pt"},
    {nome: "Floresta Everfree", descricao: "Uma floresta misteriosa e cheia de aventuras.", img: "https://static.wikia.nocookie.net/mlp/images/d/d2/Main_six_na_Floresta_Everfree_T4E2.png/revision/latest/scale-to-width-down/1000?cb=20140606122116&path-prefix=pt"},
    {nome: "Império de Cristal", descricao: "O reino brilhante protegido pelo poder do amor e da amizade.", img: "https://static.wikia.nocookie.net/mlp/images/8/84/Imperio_de_Cristal_T3E12.png/revision/latest/scale-to-width-down/1000?cb=20140606155938&path-prefix=pt"},
    {nome: "Griffonstone", descricao: "A antiga cidade dos grifos.", img: "https://static.wikia.nocookie.net/mlp/images/f/f2/Griffonstone_a_%27total_dump%27_S5E8.png/revision/latest/scale-to-width-down/1000?cb=20150525104812"},
    {nome: "Yakyakistan", descricao: "A terra dos yaks.", img: "https://static.wikia.nocookie.net/mlp/images/a/a0/Wide_view_of_Yakyakistan_as_yaks_stomp_S7E11.png/revision/latest/scale-to-width-down/1000?cb=20170618140405"},
    {nome: "Casa do Discord", descricao: "Um lugar estranho, mágico e imprevisível.", img: "https://static.wikia.nocookie.net/mlp/images/f/fd/Discord%27s_house_S5E7.png/revision/latest/scale-to-width-down/1000?cb=20150518163141"},
    {nome: "Celestia Erguendo o Sol", descricao: "Princesa Celestia usando sua magia para levantar o sol.", img: "https://static.wikia.nocookie.net/mlp/images/d/d7/Celestia_Raising_Sun_S01E01.png/revision/latest/scale-to-width-down/1000?cb=20140620011620&path-prefix=pt"},
    {nome: "Luna Erguendo a Lua", descricao: "Princesa Luna usando sua magia para levantar a lua.", img: "https://static.wikia.nocookie.net/mlp/images/7/76/Luna_Raising_Moon_S01E01.png/revision/latest/scale-to-width-down/1000?cb=20140620011923&path-prefix=pt"},
    {nome: "Ursa Maior e Ursa Menor", descricao: "Criaturas mágicas gigantes de Equestria.", img: "https://static.wikia.nocookie.net/mlp/images/8/8b/Ursa_Maior_olhando_para_Ursa_Menor_T1E06.png/revision/latest/scale-to-width-down/1000?cb=20140620012827&path-prefix=pt"},
    {nome: "Canterlot High School", descricao: "A escola do universo Equestria Girls.", img: "https://static.wikia.nocookie.net/mlp/images/d/d4/Canterlot_High_School_overhead_exterior_EG3.png/revision/latest/scale-to-width-down/1000?cb=20150702004629"},
    {nome: "Família Apple", descricao: "A família da Applejack reunida.", img: "https://static.wikia.nocookie.net/mlp/images/b/be/The_Apple_Family_together_S3E08.png/revision/latest/scale-to-width-down/1000?cb=20150211134723&path-prefix=pt"}
];

let indiceLugarAtual = 0;

function mostrarLugarAtual() {
    const lugar = lugaresEquestria[indiceLugarAtual];
    document.getElementById("mapa-titulo").innerText = lugar.nome;
    document.getElementById("mapa-imagem").src = lugar.img;
    document.getElementById("mapa-descricao").innerText = lugar.descricao;
    document.getElementById("mapa-contador").innerText = "Lugar " + (indiceLugarAtual + 1) + " de " + lugaresEquestria.length;
}

function proximoLugar() {
    indiceLugarAtual = (indiceLugarAtual + 1) % lugaresEquestria.length;
    mostrarLugarAtual();
}

function lugarAnterior() {
    indiceLugarAtual = indiceLugarAtual - 1;
    if (indiceLugarAtual < 0) indiceLugarAtual = lugaresEquestria.length - 1;
    mostrarLugarAtual();
}

mostrarLugarAtual();
</script>
