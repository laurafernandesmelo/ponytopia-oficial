<main class="pagina-lista">
    <h1>Usuários cadastrados</h1>
    <p>Esta tela comprova que os cadastros estão gravados no SQLite.</p>

    <table class="tabela">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Nascimento</th>
                <th>Gênero</th>
                <th>Pônei</th>
                <th>Criado em</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($usuarios as $usuario): ?>
                <tr>
                    <td><?= htmlspecialchars((string)$usuario['id']) ?></td>
                    <td><?= htmlspecialchars($usuario['nome']) ?></td>
                    <td><?= htmlspecialchars($usuario['nascimento'] ?? '') ?></td>
                    <td><?= htmlspecialchars($usuario['genero'] ?? '') ?></td>
                    <td><?= htmlspecialchars($usuario['poney']) ?></td>
                    <td><?= htmlspecialchars($usuario['created_at']) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</main>
