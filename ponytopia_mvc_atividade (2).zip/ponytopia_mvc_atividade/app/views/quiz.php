<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teste de Personalidade</title>
    <link href="https://fonts.googleapis.com/css2?family=Pacifico&family=Quicksand:wght@500;700&display=swap" rel="stylesheet">
    <style>
        body {
            margin: 0;
            min-height: 100vh;
            font-family: 'Quicksand', sans-serif;
            background: radial-gradient(circle, #fbc2eb 0%, #a6c1ee 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        #quiz-box {
            background: white;
            max-width: 650px;
            width: 100%;
            border-radius: 25px;
            padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.18);
            border: 4px solid #e195ff;
            text-align: center;
        }
        h1 { font-family: 'Pacifico', cursive; color: #6a1b9a; }
        h2 { color: #4a148c; }
        button {
            width: 100%;
            margin: 8px 0;
            padding: 14px;
            border: none;
            border-radius: 15px;
            background: #6a1b9a;
            color: white;
            font-weight: bold;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover { background: #8e24aa; }
        .btn-voltar { display:inline-block; margin-top:15px; color:#6a1b9a; font-weight:bold; text-decoration:none; }
        .resultado { font-size: 20px; color:#4a148c; font-weight:bold; }
    </style>
</head>
<body>
    <div id="quiz-box">
        <h1>Teste de Personalidade</h1>
        <div id="conteudo-quiz"></div>
        <a class="btn-voltar" href="/home">⬅ Voltar ao Ponytopia</a>
    </div>

    <script>
        const perguntas = [
            {
                texto: "O que você mais valoriza em uma amizade?",
                respostas: [
                    {texto: "Lealdade", ponto: "Rainbow Dash"},
                    {texto: "Bondade", ponto: "Fluttershy"},
                    {texto: "Honestidade", ponto: "Applejack"},
                    {texto: "Alegria", ponto: "Pinkie Pie"}
                ]
            },
            {
                texto: "Qual atividade você escolheria?",
                respostas: [
                    {texto: "Estudar magia", ponto: "Twilight Sparkle"},
                    {texto: "Cuidar dos animais", ponto: "Fluttershy"},
                    {texto: "Criar roupas lindas", ponto: "Rarity"},
                    {texto: "Fazer uma festa", ponto: "Pinkie Pie"}
                ]
            },
            {
                texto: "Como você resolve problemas?",
                respostas: [
                    {texto: "Pensando e planejando", ponto: "Twilight Sparkle"},
                    {texto: "Com coragem", ponto: "Rainbow Dash"},
                    {texto: "Com sinceridade", ponto: "Applejack"},
                    {texto: "Com generosidade", ponto: "Rarity"}
                ]
            }
        ];

        let atual = 0;
        const pontos = {};
        const conteudo = document.getElementById('conteudo-quiz');

        function mostrarPergunta() {
            const pergunta = perguntas[atual];
            conteudo.innerHTML = `<h2>${pergunta.texto}</h2>`;
            pergunta.respostas.forEach(resposta => {
                const btn = document.createElement('button');
                btn.textContent = resposta.texto;
                btn.onclick = () => responder(resposta.ponto);
                conteudo.appendChild(btn);
            });
        }

        function responder(ponto) {
            pontos[ponto] = (pontos[ponto] || 0) + 1;
            atual++;
            if (atual < perguntas.length) {
                mostrarPergunta();
            } else {
                mostrarResultado();
            }
        }

        function mostrarResultado() {
            let resultado = Object.keys(pontos).sort((a, b) => pontos[b] - pontos[a])[0];
            conteudo.innerHTML = `
                <p class="resultado">Seu resultado é: ${resultado}</p>
                <p>Esse resultado será salvo no SQLite pelo fluxo Controller → Service → Model.</p>
                <button onclick="location.reload()">Refazer Quiz</button>
            `;

            const dados = new FormData();
            dados.append('resultado', resultado);

            fetch('/quiz/resultado', {
                method: 'POST',
                body: dados
            });
        }

        mostrarPergunta();
    </script>
</body>
</html>
