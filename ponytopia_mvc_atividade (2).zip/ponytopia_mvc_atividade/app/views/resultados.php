<main class="pagina-lista">
    <h1>Resultados do Quiz</h1>
    <p>Esta tela mostra os resultados salvos pelo fluxo QuizController → QuizService → QuizResultadoModel → SQLite.</p>

    <table class="tabela">
        <thead>
            <tr>
                <th>ID</th>
                <th>Usuário</th>
                <th>Resultado</th>
                <th>Criado em</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($resultados as $resultado): ?>
                <tr>
                    <td><?= htmlspecialchars((string)$resultado['id']) ?></td>
                    <td><?= htmlspecialchars($resultado['nome_usuario']) ?></td>
                    <td><?= htmlspecialchars($resultado['resultado']) ?></td>
                    <td><?= htmlspecialchars($resultado['created_at']) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</main>
