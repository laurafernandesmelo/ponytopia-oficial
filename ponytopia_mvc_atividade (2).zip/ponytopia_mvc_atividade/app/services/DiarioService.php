<?php

declare(strict_types=1);

class DiarioService
{
    public function nomeDaTela(): string
    {
        return 'Diário de Amizade / PONYCOLOR';
    }
}
