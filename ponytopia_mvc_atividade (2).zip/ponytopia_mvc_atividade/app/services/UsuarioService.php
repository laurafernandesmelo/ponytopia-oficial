<?php

declare(strict_types=1);

class UsuarioService
{
    private UsuarioModel $usuarioModel;

    public function __construct()
    {
        $this->usuarioModel = new UsuarioModel();
    }

    public function criarUsuario(array $dados): array
    {
        if ($dados['nome'] === '') {
            return ['ok' => false, 'mensagem' => 'Informe o nome do usuário.'];
        }

        if ($dados['senha'] === '') {
            return ['ok' => false, 'mensagem' => 'Informe a senha.'];
        }

        if ($dados['poney'] === '') {
            return ['ok' => false, 'mensagem' => 'Escolha um pônei.'];
        }

        if ($this->usuarioModel->buscarPorNome($dados['nome'])) {
            return ['ok' => false, 'mensagem' => 'Este nome de usuário já existe.'];
        }

        $usuarioId = $this->usuarioModel->criar([
            'nome' => $dados['nome'],
            'nascimento' => $dados['nascimento'],
            'genero' => $dados['genero'],
            'senha_hash' => password_hash($dados['senha'], PASSWORD_DEFAULT),
            'poney' => $dados['poney'],
        ]);

        return [
            'ok' => true,
            'usuario' => [
                'id' => $usuarioId,
                'nome' => $dados['nome'],
                'poney' => $dados['poney'],
            ],
        ];
    }

    public function autenticar(string $nome, string $senha): ?array
    {
        $usuario = $this->usuarioModel->buscarPorNome($nome);

        if (!$usuario || !password_verify($senha, $usuario['senha_hash'])) {
            return null;
        }

        return [
            'id' => (int)$usuario['id'],
            'nome' => $usuario['nome'],
            'poney' => $usuario['poney'],
        ];
    }

    public function listarUsuarios(): array
    {
        return $this->usuarioModel->listarTodos();
    }
}
