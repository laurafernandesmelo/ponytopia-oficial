<?php

declare(strict_types=1);

class QuizService
{
    private QuizResultadoModel $quizResultadoModel;

    public function __construct()
    {
        $this->quizResultadoModel = new QuizResultadoModel();
    }

    public function salvarResultado(array $dados): array
    {
        if (($dados['resultado'] ?? '') === '') {
            return ['ok' => false, 'mensagem' => 'Resultado vazio.'];
        }

        $this->quizResultadoModel->criar($dados);
        return ['ok' => true, 'mensagem' => 'Resultado salvo com sucesso.'];
    }

    public function listarResultados(): array
    {
        return $this->quizResultadoModel->listarTodos();
    }
}
