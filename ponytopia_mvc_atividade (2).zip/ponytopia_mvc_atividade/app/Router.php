<?php

declare(strict_types=1);

class Router
{
    private array $routes = [];

    public function get(string $path, string $action): void
    {
        $this->addRoute('GET', $path, $action);
    }

    public function post(string $path, string $action): void
    {
        $this->addRoute('POST', $path, $action);
    }

    private function addRoute(string $method, string $path, string $action): void
    {
        $this->routes[$method][$this->normalizePath($path)] = $action;
    }

    public function dispatch(string $uri, string $method): void
    {
        $path = parse_url($uri, PHP_URL_PATH) ?: '/';
        $path = $this->normalizePath($path);
        $method = strtoupper($method);

        if (!isset($this->routes[$method][$path])) {
            http_response_code(404);
            echo '<h1>404 - Rota não encontrada</h1>';
            echo '<p>A rota <strong>' . htmlspecialchars($path) . '</strong> não existe.</p>';
            echo '<p><a href="/home">Voltar para Home</a></p>';
            return;
        }

        [$controllerName, $methodName] = explode('@', $this->routes[$method][$path]);

        if (!class_exists($controllerName)) {
            throw new RuntimeException("Controller {$controllerName} não encontrado.");
        }

        $controller = new $controllerName();

        if (!method_exists($controller, $methodName)) {
            throw new RuntimeException("Método {$methodName} não encontrado em {$controllerName}.");
        }

        $controller->$methodName();
    }

    private function normalizePath(string $path): string
    {
        $path = '/' . trim($path, '/');
        return $path === '/' ? '/' : rtrim($path, '/');
    }
}
