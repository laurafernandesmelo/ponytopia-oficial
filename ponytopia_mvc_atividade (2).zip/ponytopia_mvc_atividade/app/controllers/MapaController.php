<?php

declare(strict_types=1);

class MapaController extends BaseController
{
    public function index(): void
    {
        $this->exigirLogin();
        $this->view('mapa', ['titulo' => 'Mapa de Equestria']);
    }
}
