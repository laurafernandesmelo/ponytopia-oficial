<?php

declare(strict_types=1);

class UsuarioController extends BaseController
{
    private UsuarioService $usuarioService;

    public function __construct()
    {
        $this->usuarioService = new UsuarioService();
    }

    public function criar(): void
    {
        $this->view('cadastro', [
            'titulo' => 'Cadastro - Ponytopia',
            'erro' => $_SESSION['erro'] ?? null,
            'dados' => $_SESSION['dados'] ?? [],
        ]);

        unset($_SESSION['erro'], $_SESSION['dados']);
    }

    public function salvar(): void
    {
        $dados = [
            'nome' => trim($_POST['nome'] ?? ''),
            'nascimento' => trim($_POST['nascimento'] ?? ''),
            'genero' => trim($_POST['genero'] ?? ''),
            'senha' => $_POST['senha'] ?? '',
            'poney' => trim($_POST['poney'] ?? ''),
        ];

        $resultado = $this->usuarioService->criarUsuario($dados);

        if (!$resultado['ok']) {
            $_SESSION['erro'] = $resultado['mensagem'];
            $_SESSION['dados'] = $dados;
            $this->redirect('/cadastro');
        }

        $_SESSION['usuario'] = $resultado['usuario'];
        $this->redirect('/home');
    }

    public function listar(): void
    {
        $this->exigirLogin();
        $this->view('usuarios', [
            'titulo' => 'Usuários - Ponytopia',
            'usuarios' => $this->usuarioService->listarUsuarios(),
        ]);
    }
}
