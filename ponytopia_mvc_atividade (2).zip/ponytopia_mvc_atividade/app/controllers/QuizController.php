<?php

declare(strict_types=1);

class QuizController extends BaseController
{
    private QuizService $quizService;

    public function __construct()
    {
        $this->quizService = new QuizService();
    }

    public function index(): void
    {
        $this->exigirLogin();
        $this->view('quiz', ['titulo' => 'Teste de Personalidade'], false);
    }

    public function salvarResultado(): void
    {
        $this->exigirLogin();

        $resultado = trim($_POST['resultado'] ?? '');
        $usuario = $this->usuarioLogado();

        $salvo = $this->quizService->salvarResultado([
            'usuario_id' => $usuario['id'] ?? null,
            'nome_usuario' => $usuario['nome'] ?? 'Visitante',
            'resultado' => $resultado,
        ]);

        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($salvo);
    }
}
