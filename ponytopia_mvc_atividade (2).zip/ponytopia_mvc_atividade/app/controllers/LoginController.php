<?php

declare(strict_types=1);

class LoginController extends BaseController
{
    private UsuarioService $usuarioService;

    public function __construct()
    {
        $this->usuarioService = new UsuarioService();
    }

    public function index(): void
    {
        $this->view('login', [
            'titulo' => 'Login - Ponytopia',
            'erro' => $_SESSION['erro'] ?? null,
        ]);
        unset($_SESSION['erro']);
    }

    public function entrar(): void
    {
        $nome = trim($_POST['nome'] ?? '');
        $senha = $_POST['senha'] ?? '';

        $usuario = $this->usuarioService->autenticar($nome, $senha);

        if (!$usuario) {
            $_SESSION['erro'] = 'Nome ou senha incorretos.';
            $this->redirect('/login');
        }

        $_SESSION['usuario'] = $usuario;
        $this->redirect('/home');
    }

    public function visitante(): void
    {
        $_SESSION['usuario'] = [
            'id' => 0,
            'nome' => 'Visitante',
            'poney' => 'Twilight',
        ];

        $this->redirect('/home');
    }

    public function sair(): void
    {
        session_destroy();
        $this->redirect('/login');
    }
}
