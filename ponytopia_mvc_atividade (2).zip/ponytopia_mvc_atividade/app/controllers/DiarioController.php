<?php

declare(strict_types=1);

class DiarioController extends BaseController
{
    public function index(): void
    {
        $this->exigirLogin();
        $this->view('diario_amizade', ['titulo' => 'PONYCOLOR - Diário de Amizade'], false);
    }
}
