<?php

declare(strict_types=1);

class ResultadoController extends BaseController
{
    private QuizService $quizService;

    public function __construct()
    {
        $this->quizService = new QuizService();
    }

    public function index(): void
    {
        $this->exigirLogin();
        $this->view('resultados', [
            'titulo' => 'Resultados do Quiz',
            'resultados' => $this->quizService->listarResultados(),
        ]);
    }
}
