<?php

declare(strict_types=1);

abstract class BaseController
{
    protected function view(string $view, array $data = [], bool $useLayout = true): void
    {
        extract($data);
        $viewFile = dirname(__DIR__) . '/views/' . $view . '.php';

        if (!is_file($viewFile)) {
            throw new RuntimeException("View {$view} não encontrada.");
        }

        if ($useLayout) {
            require dirname(__DIR__) . '/views/layout/header.php';
            require $viewFile;
            require dirname(__DIR__) . '/views/layout/footer.php';
            return;
        }

        require $viewFile;
    }

    protected function redirect(string $url): void
    {
        header('Location: ' . $url);
        exit;
    }

    protected function usuarioLogado(): ?array
    {
        return $_SESSION['usuario'] ?? null;
    }

    protected function exigirLogin(): void
    {
        if (!$this->usuarioLogado()) {
            $this->redirect('/login');
        }
    }
}
