<?php

declare(strict_types=1);

class RarityController extends BaseController
{
    public function index(): void
    {
        $this->exigirLogin();
        $this->view('rarity', ['titulo' => 'Boutique da Rarity'], false);
    }
}
