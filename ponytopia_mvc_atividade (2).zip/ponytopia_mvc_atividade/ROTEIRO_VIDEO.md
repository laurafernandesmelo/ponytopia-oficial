# Roteiro do vídeo da atividade

## Passo 1 - Preparar gravação

- Abrir o gravador de tela.
- Ativar a webcam durante todo o vídeo.
- Deixar o rosto aparecendo no canto da tela.
- Abrir o projeto no VS Code.
- Deixar visível a árvore de arquivos.

## Passo 2 - Identificação inicial

Falar nos primeiros 30 segundos:

> Olá, meu nome é [SEU NOME COMPLETO], sou da turma [SUA TURMA/CURSO], e hoje vou explicar a estrutura interna e o fluxo de dados da minha aplicação Ponytopia, desenvolvida em PHP usando o padrão MVC. O projeto possui Home, Mapa de Equestria, Teste de Personalidade, Diário de Amizade com PONYCOLOR e Boutique da Rarity.

## Passo 3 - Mostrar o código

### Router

Abrir:

- `routes/web.php`
- `app/Router.php`

Explicar:

> O arquivo de rotas define qual URL chama qual controller. O Router recebe a URL, verifica o método GET ou POST e chama o controller correspondente.

### Controller

Abrir:

- `app/controllers/UsuarioController.php`
- `app/controllers/QuizController.php`
- `app/controllers/MapaController.php`
- `app/controllers/DiarioController.php`
- `app/controllers/RarityController.php`

Explicar:

> O Controller recebe a requisição da rota. No cadastro, o UsuarioController recebe os dados do formulário e repassa para o UsuarioService. No quiz, o QuizController recebe o resultado e repassa para o QuizService.

### Service

Abrir:

- `app/services/UsuarioService.php`
- `app/services/QuizService.php`

Explicar:

> O Service contém as regras de negócio. O UsuarioService valida nome, senha, pônei escolhido e se o usuário já existe. O QuizService valida e salva o resultado do quiz.

### Model e Migrations

Abrir:

- `app/models/UsuarioModel.php`
- `app/models/QuizResultadoModel.php`
- `app/migrations/001_create_usuarios.php`
- `app/migrations/002_create_quiz_resultados.php`

Explicar:

> As migrations criam as tabelas do banco SQLite. Os models são responsáveis por executar os INSERTs e SELECTs nessas tabelas.

### Database

Abrir:

- `app/database/Database.php`

Explicar:

> O Database cria a conexão PDO com o arquivo `database/banco.sqlite`.

## Passo 4 - Teste vivo

Rodar no terminal:

```bash
php migrate.php
php -S localhost:8000 -t public
```

Abrir:

```text
http://localhost:8000
```

### Demonstrar cadastro

Falar:

> Ao clicar em concluir cadastro, o formulário envia os dados para a rota `/usuarios/salvar`. Essa rota chama `UsuarioController@salvar`, que envia os dados para `UsuarioService::criarUsuario`. O service valida as regras e chama `UsuarioModel::criar`, que grava na tabela `usuarios` do SQLite.

Depois abrir:

```text
http://localhost:8000/usuarios
```

E mostrar o usuário salvo.

### Demonstrar quiz

Abrir:

```text
http://localhost:8000/quiz
```

Responder o quiz.

Falar:

> Ao terminar o quiz, o resultado é enviado para `/quiz/resultado`. Essa rota chama o QuizController, que usa o QuizService e o QuizResultadoModel para salvar o resultado no SQLite.

Depois abrir:

```text
http://localhost:8000/resultados
```

E mostrar o resultado salvo.

## Passo 5 - YouTube

- Gravar vídeo entre 4 e 8 minutos.
- Enviar para o YouTube como Público ou Não listado.
- Não deixar como Privado.
- Testar o link em aba anônima.

## Passo 6 - README

Abrir `README.md` e trocar:

```text
COLE_AQUI_O_LINK_DO_VIDEO
```

pelo link real do YouTube.
