<?php

// Login, cadastro e visitante
$router->get('/', 'LoginController@index');
$router->get('/login', 'LoginController@index');
$router->post('/login/entrar', 'LoginController@entrar');
$router->get('/visitante', 'LoginController@visitante');
$router->get('/logout', 'LoginController@sair');

// Usuários
$router->get('/cadastro', 'UsuarioController@criar');
$router->post('/usuarios/salvar', 'UsuarioController@salvar');
$router->get('/usuarios', 'UsuarioController@listar');

// Telas principais do site
$router->get('/home', 'HomeController@index');
$router->get('/mapa', 'MapaController@index');
$router->get('/quiz', 'QuizController@index');
$router->post('/quiz/resultado', 'QuizController@salvarResultado');
$router->get('/resultados', 'ResultadoController@index');
$router->get('/diario-amizade', 'DiarioController@index');
$router->get('/rarity', 'RarityController@index');
