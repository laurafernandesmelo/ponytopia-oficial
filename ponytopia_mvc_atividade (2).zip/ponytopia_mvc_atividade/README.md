# Ponytopia MVC

Projeto MVC em PHP usando SQLite, baseado no site Ponytopia.

## Telas do site

- `/login` - Login
- `/cadastro` - Cadastro de usuário
- `/home` - Home do Ponytopia
- `/mapa` - Mapa de Equestria
- `/quiz` - Teste de Personalidade
- `/diario-amizade` - PONYCOLOR / Diário de Amizade
- `/rarity` - Boutique da Rarity
- `/usuarios` - Usuários salvos no SQLite
- `/resultados` - Resultados do quiz salvos no SQLite

## Estrutura MVC

```text
public/index.php          Entrada da aplicação
routes/web.php            Rotas do sistema
app/Router.php            Captura a URL e chama o Controller
app/controllers/          Controllers
app/services/             Regras de negócio
app/models/               Acesso aos dados
app/migrations/           Criação das tabelas
app/database/Database.php Conexão com o SQLite
app/views/                Telas do site
```

## Como rodar

No terminal, dentro da pasta do projeto:

```bash
php check_requirements.php
php migrate.php
php -S localhost:8000 -t public
```

Acesse:

```text
http://localhost:8000
```

## Fluxo para demonstrar na atividade

### Cadastro de usuário

1. Abrir `/cadastro`.
2. Preencher nome, senha e escolher um pônei.
3. Clicar em concluir cadastro.
4. O formulário envia os dados para `/usuarios/salvar`.
5. A rota chama `UsuarioController@salvar`.
6. O controller chama `UsuarioService::criarUsuario`.
7. O service valida os dados.
8. O service chama `UsuarioModel::criar`.
9. O model grava na tabela `usuarios` do SQLite.
10. O sistema redireciona para `/home`.

### Resultado do quiz

1. Abrir `/quiz`.
2. Responder as perguntas.
3. O resultado é enviado por POST para `/quiz/resultado`.
4. A rota chama `QuizController@salvarResultado`.
5. O controller chama `QuizService`.
6. O service chama `QuizResultadoModel`.
7. O model grava na tabela `quiz_resultados`.
8. A tela `/resultados` mostra os resultados salvos.

## Vídeo de apresentação

Link do vídeo no YouTube: COLE_AQUI_O_LINK_DO_VIDEO
