<?php

echo 'Verificando requisitos do Ponytopia MVC...' . PHP_EOL;
echo 'PHP: ' . PHP_VERSION . PHP_EOL;

echo extension_loaded('pdo') ? '[OK] PDO habilitado' . PHP_EOL : '[ERRO] PDO não está habilitado' . PHP_EOL;
echo extension_loaded('pdo_sqlite') ? '[OK] PDO SQLite habilitado' . PHP_EOL : '[ERRO] PDO SQLite não está habilitado' . PHP_EOL;

echo PHP_EOL;
echo 'Para rodar:' . PHP_EOL;
echo 'php migrate.php' . PHP_EOL;
echo 'php -S localhost:8000 -t public' . PHP_EOL;
