<?php

declare(strict_types=1);

require __DIR__ . '/app/database/Database.php';

$db = Database::getConnection();
$migrations = glob(__DIR__ . '/app/migrations/*.php');
sort($migrations);

foreach ($migrations as $migrationFile) {
    $migration = require $migrationFile;
    $migration($db);
    echo 'Executada: ' . basename($migrationFile) . PHP_EOL;
}

echo 'Banco SQLite pronto em database/banco.sqlite' . PHP_EOL;
